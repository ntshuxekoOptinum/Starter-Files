% etc_plant_data.m
%
% Loads parameter data for the Throttle system

J = 2.45e-4;      % Throttle plate inertia[kg*m^2]
Km = 3;           % Motor constant [N*m]
Kd = 0.03;        % Viscous friction/damping coefficient [N*m*s/rad]
Ks = 0.2;         % Spring constant [N*m/rad]
theta_eq = pi/6;  % Spring equilibrium angle [rad]