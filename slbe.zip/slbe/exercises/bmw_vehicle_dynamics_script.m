% Load vehicle parameters
bmwParams;

% Loop over drive force values
for Fdrive = 1000:100:2000
    % Simulate the model and get simulation data
    out = sim("bmw_vehicle_dynamics","StopTime","5");

    % Get time and velocity (in feet per second) from results
    t = out.simout.Time;
    v_fps = out.simout.Data;
    
    % Convert velocity to miles per hour
    v_mph = v_fps*60*60/5280;
    
    % Stop iterating if the maximum speed is >= 60 mph
    if max(v_mph)>=60
        break
    end
end

% Display the minimum spring constant
disp("Minimum driving force Fdrive = " + Fdrive + " lbf")

% Plot the last simulation results
plot(t,v_mph)
xlabel("Time (s)")
ylabel("Velocity (mph)")
title("Minimum driving force Fdrive = " + Fdrive + " lbf")