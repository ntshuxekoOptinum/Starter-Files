% Load the bungee parameters
bungeeParams;

% Loop over spring constant values
for k = 1:50
    % Run simulation
    out = sim("bungee","StopTime","50");

    % Get time and position data from results
    t = out.simout.Time;
    y = out.simout.Data;

    % Break the loop if the bungee jumper did not go below zero
    if min(y)>0
        break
    end
end

% Display the minimum spring constant
disp("Minimum spring constant k = " + k)

% Plot the last simulation results
plot(t,y)
xlabel("Time (s)")
ylabel("Position (m)")
title("Minimum spring constant k = " + k)